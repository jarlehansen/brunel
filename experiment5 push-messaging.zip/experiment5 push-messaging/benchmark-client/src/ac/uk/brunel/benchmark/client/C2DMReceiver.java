package ac.uk.brunel.benchmark.client;

import com.googlecode.sc2dm.integration.SC2DMReceiver;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 6:10 PM - 11/21/11
 */
public class C2DMReceiver extends SC2DMReceiver {
}

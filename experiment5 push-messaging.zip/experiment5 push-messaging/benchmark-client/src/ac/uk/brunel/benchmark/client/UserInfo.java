package ac.uk.brunel.benchmark.client;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 6:07 PM - 11/21/11
 */
public enum UserInfo {
    ;

    public static final String EMAIL = "";
    public static final String PASSWORD = "";
}

package ac.uk.brunel.benchmark.server.persistence;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 6:05 PM - 10/6/11
 */
public interface GoogleAuthDao {
    public String getAuthToken();
}

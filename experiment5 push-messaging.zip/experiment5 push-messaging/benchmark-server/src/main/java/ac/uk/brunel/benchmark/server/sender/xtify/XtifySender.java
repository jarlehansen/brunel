package ac.uk.brunel.benchmark.server.sender.xtify;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 5:47 PM - 11/22/11
 */
public class XtifySender {

    public void send(String message) {

        
    }
}

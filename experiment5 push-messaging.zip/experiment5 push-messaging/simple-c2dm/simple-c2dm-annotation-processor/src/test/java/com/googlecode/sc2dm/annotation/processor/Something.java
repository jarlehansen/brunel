package com.googlecode.sc2dm.annotation.processor;

import com.googlecode.sc2dm.annotations.SC2DMAutomaticManifest;

import java.io.File;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 1:16 PM - 11/20/11
 */
@SC2DMAutomaticManifest
public class Something {
}
 
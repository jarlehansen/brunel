#! /bin/bash

javac -cp ../build/libs/simple-c2dm-annotation-processor.jar -processor com.googlecode.sc2dm.annotation.processor.SC2DMAnnotationProcessor ../src/test/java/com/googlecode/sc2dm/annotation/processor/Something.java -AmanifestDir=/Users/hansjar/workspace/idea/simple-c2dm/simple-c2dm-annotation-processor
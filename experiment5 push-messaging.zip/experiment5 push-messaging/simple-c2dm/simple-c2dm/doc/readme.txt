Turn on debug logging on device:
./adb shell setprop log.tag.simple-c2dm DEBUG
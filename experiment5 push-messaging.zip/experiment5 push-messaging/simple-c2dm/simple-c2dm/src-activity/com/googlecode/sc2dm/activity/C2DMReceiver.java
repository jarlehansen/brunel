package com.googlecode.sc2dm.activity;

import com.googlecode.sc2dm.integration.SC2DMReceiver;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 11:24 AM - 9/22/11
 */
public class C2DMReceiver extends SC2DMReceiver {
}

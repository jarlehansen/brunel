package com.googlecode.sc2dm;

import android.content.Context;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 6:28 PM - 9/18/11
 */
public interface PushMessages {
    public void enable();
}

To install the ping servlet:
##############################
1. Upload application to App Engine and go to the url with your browser: http://ping-servlet.appspot.com/. This will initialize the datastore
3. Run the GoogleAuthTokenMain application (in src/test/java) to generate a token
4. With the "Datastore Viewer" in the App Engine admin (appspot.com), paste the generated token into the field already created
package com.googlecode.sc2dm.annotations.util;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 9:03 PM - 9/19/11
 */
public class NotAnnotated {

    public void method1() {
    }

    public String method2() {
        return "";
    }
}

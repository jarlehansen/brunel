package com.googlecode.sc2dm.server.sender;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 5:05 PM - 11/17/11
 */
public interface AuthTokenUpdater {
    public void updateToken(String token);
}

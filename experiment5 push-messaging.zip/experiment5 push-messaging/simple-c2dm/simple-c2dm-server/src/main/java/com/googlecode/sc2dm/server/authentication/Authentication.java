package com.googlecode.sc2dm.server.authentication;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 8:45 PM - 1/7/11
 */
public interface Authentication {
    public String getAuthToken();
}

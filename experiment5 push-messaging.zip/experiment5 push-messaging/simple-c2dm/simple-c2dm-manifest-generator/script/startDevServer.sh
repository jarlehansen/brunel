#! /bin/bash

# Remember to update gradle.properties!
app_engine_home=$(cat ../../gradle.properties | grep -o '/.*')
echo "APP_ENGINE_HOME=$app_engine_home"
sh $app_engine_home/bin/dev_appserver.sh --disable_update_check ../build/exploded-war
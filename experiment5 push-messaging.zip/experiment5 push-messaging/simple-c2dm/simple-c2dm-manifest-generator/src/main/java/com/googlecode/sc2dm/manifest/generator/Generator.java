package com.googlecode.sc2dm.manifest.generator;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 10:18 PM - 9/24/11
 */
public interface Generator {
    public String generate(String packageName);
}

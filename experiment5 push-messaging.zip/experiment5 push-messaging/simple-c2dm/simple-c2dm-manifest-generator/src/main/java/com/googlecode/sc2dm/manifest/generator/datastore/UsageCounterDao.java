package com.googlecode.sc2dm.manifest.generator.datastore;

import java.util.Date;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 8:05 PM - 9/27/11
 */
public interface UsageCounterDao {
    public void storeStats();
}

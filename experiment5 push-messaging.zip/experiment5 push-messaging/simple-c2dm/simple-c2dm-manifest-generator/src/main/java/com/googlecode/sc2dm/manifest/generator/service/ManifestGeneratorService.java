package com.googlecode.sc2dm.manifest.generator.service;

/**
 * @Author Jarle Hansen (jarle@jarlehansen.net)
 * Created: 8:07 PM - 9/27/11
 */
public interface ManifestGeneratorService {
    public GeneratedXml generate(String packageName);
}
